import streamlit as st
from src.predict import predict_sign

st.title("Traffic Sign Recognition")
uploaded_file = st.file_uploader("Upload a Traffic Sign Image", type=["jpg", "png"])

if uploaded_file:
    st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)
    with open("temp.jpg", "wb") as f:
        f.write(uploaded_file.getbuffer())
    class_id = predict_sign("temp.jpg")
    st.write(f"Predicted Traffic Sign Class: {class_id}")