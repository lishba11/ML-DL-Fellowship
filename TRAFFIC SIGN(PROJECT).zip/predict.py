from tensorflow.keras.models import load_model
import numpy as np
from src.preprocessing import preprocess_image

def predict_sign(image_path, model_path="model.h5"):
    model = load_model(model_path)
    image = preprocess_image(image_path)
    image = np.expand_dims(image, axis=0)  # Add batch dimension
    prediction = model.predict(image)
    class_id = np.argmax(prediction)
    return class_id