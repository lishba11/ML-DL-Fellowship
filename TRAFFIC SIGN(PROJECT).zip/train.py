from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import numpy as np
from src.preprocessing import preprocess_image
from src.model import create_model

# Load dataset
def load_dataset(dataset_path):
    # Assume dataset is already unpacked and structured
    # Read images and labels into arrays
    images, labels = [], []
    # Add your dataset loading logic here...
    return np.array(images), np.array(labels)

dataset_path = "data/GTSRB/"
images, labels = load_dataset(dataset_path)

# Split and preprocess
X_train, X_val, y_train, y_val = train_test_split(images, labels, test_size=0.2, random_state=42)
X_train = np.array([preprocess_image(img) for img in X_train])
X_val = np.array([preprocess_image(img) for img in X_val])
y_train, y_val = to_categorical(y_train), to_categorical(y_val)

# Augmentation
datagen = ImageDataGenerator(rotation_range=10, zoom_range=0.1, width_shift_range=0.1, height_shift_range=0.1)

# Model
model = create_model(input_shape=X_train.shape[1:], num_classes=y_train.shape[1])

# Train
history = model.fit(datagen.flow(X_train, y_train, batch_size=32),
                    validation_data=(X_val, y_val),
                    epochs=10)