# Traffic Sign Recognition

This project implements a Traffic Sign Recognition system using the GTSRB dataset and a CNN model.

## Features
- Preprocessing pipeline for image resizing and normalization.
- CNN model for traffic sign classification.
- UI for uploading traffic sign images and displaying predictions.

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/lishba11/traffic-sign-recognition.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage
1. Train the model:
   ```bash
   python src/train.py
   ```
2. Run the UI:
   ```bash
   streamlit run ui/app.py
   ```
3. Upload a traffic sign image to get predictions.

## Dataset
Download the [GTSRB dataset](https://benchmark.ini.rub.de/gtsrb_news.html) and place it in the `data/` directory.